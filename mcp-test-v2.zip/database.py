# file: database.py

import sqlite3

def get_db_connection():
    conn = sqlite3.connect('config.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    cursor = conn.cursor()

    # Create OpenAI key table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS openai_config (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            api_key TEXT
        )
    ''')

    # Create MCP Servers table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS mcp_servers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mcp_id TEXT UNIQUE,
            name TEXT,
            base_url TEXT,
            manifest TEXT
        )
    ''')

    # Create Chat History table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT,
            session_title TEXT,
            user_prompt TEXT,
            steps_json TEXT,
            final_answer TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')

    conn.commit()
    conn.close()

# --- Initialize DB when module is imported ---
init_db()
