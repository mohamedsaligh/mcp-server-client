# file: backend_server.py

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from typing import List, Dict, Any
import httpx
import asyncio
import uuid
from openai import OpenAI
import json

from database import get_db_connection


app = FastAPI(title="MCP Orchestration Backend")

# --- Models ---
class MCPServerConfig(BaseModel):
    name: str
    base_url: str

class UserPromptRequest(BaseModel):
    prompt: str
    session_id: str
    # No selected_mcp_ids anymore


def set_openai_key(api_key: str):
    conn = get_db_connection()
    conn.execute('DELETE FROM openai_config')
    conn.execute('INSERT INTO openai_config (api_key) VALUES (?)', (api_key,))
    conn.commit()
    conn.close()

def get_openai_key() -> str:
    conn = get_db_connection()
    row = conn.execute('SELECT api_key FROM openai_config').fetchone()
    conn.close()
    return row['api_key'] if row else ""


def add_mcp_server_db(name: str, base_url: str, manifest: dict):
    mcp_id = str(uuid.uuid4())
    conn = get_db_connection()
    conn.execute(
        'INSERT INTO mcp_servers (mcp_id, name, base_url, manifest) VALUES (?, ?, ?, ?)',
        (mcp_id, name, base_url, json.dumps(manifest))
    )
    conn.commit()
    conn.close()
    return mcp_id

def list_mcp_servers_db():
    conn = get_db_connection()
    rows = conn.execute('SELECT * FROM mcp_servers').fetchall()
    conn.close()
    return [dict(row) for row in rows]

def delete_mcp_server_db(mcp_id: str):
    conn = get_db_connection()
    conn.execute('DELETE FROM mcp_servers WHERE mcp_id = ?', (mcp_id,))
    conn.commit()
    conn.close()

def save_chat_history(session_id: str, session_title: str, user_prompt: str, steps: List[Dict[str, Any]], final_answer: str):
    if not session_title or session_title.strip() == "":
        print(f"Skipping save: Empty session_title for session_id {session_id}")
        return  # do not save if title is empty
    conn = get_db_connection()
    conn.execute(
        "INSERT INTO chat_history (session_id, session_title, user_prompt, steps_json, final_answer) VALUES (?, ?, ?, ?, ?)",
        (session_id, session_title, user_prompt, json.dumps(steps), final_answer)
    )
    conn.commit()
    conn.close()


def load_chat_history(session_id: str) -> List[Dict[str, Any]]:
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT user_prompt, steps_json, final_answer FROM chat_history WHERE session_id = ? ORDER BY created_at",
        (session_id,)
    ).fetchall()
    conn.close()
    return [
        {
            "user_prompt": row["user_prompt"],
            "steps": json.loads(row["steps_json"]),
            "final_answer": row["final_answer"]
        }
        for row in rows
    ]


# --- Utils ---
async def fetch_manifest(base_url: str) -> Dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{base_url}/manifest.json")
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        print(f"Manifest fetch failed for {base_url}: {str(e)}")
        return {}

async def call_openai(refinement_prompt: str, manifest_data: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    openai_key = get_openai_key()
    if not openai_key:
        raise HTTPException(status_code=400, detail="OpenAI API key not configured")
    
    client = OpenAI(api_key=openai_key)

    system_instruction = (
        "You are a smart orchestrator that prepares payloads for MCP servers based on the user's prompt. "
        "You are provided with available MCP servers, each with actions and their expected input models.\n\n"
        "Your task is:\n"
        "- Select correct servers and actions.\n"
        "- Prepare the correct payload matching the input_model exactly.\n"
        "- Chain the servers properly if needed. Use outputs of one server as input for another.\n\n"
        "IMPORTANT rules:\n"
        "- NEVER solve mathematical expressions yourself (like 5 + 8).\n"
        "- If the prompt involves basic math operations (sum, addition, multiplication), you must call the Math Calculator server.\n"
        "- Example: If user says 'sum of 5 and 8', prepare a request to Math Calculator with inputs [5,8] and operation 'sum'.\n"
        "- Use outputs of earlier MCP server responses for later requests if needed.\n"
        "- Do not guess results. Always plan actions properly.\n\n"
        "Special Rules:\n"
        "- When the user asks to perform calculations across multiple steps (e.g., calculate several areas then add), "
        "you must **carry forward the intermediate results**.\n"
        "- Always extract numbers correctly.\n"
        "- Always respond with a pure JSON list.\n"
        "- No explanations. Only return the clean JSON list as final response.\n\n"
        "Response format:\n"
        "- Only respond with a pure JSON list.\n"
        "- Each item must include:\n"
        "    - server_name (string)\n"
        "    - payload (dictionary matching the input model)\n"
    )



    full_prompt = f"""User Prompt: {refinement_prompt}

    Available MCP Servers:
    {json.dumps(manifest_data, indent=2)}

    Reply ONLY with a valid JSON list."""
    
    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": full_prompt}
            ],
            temperature=0,
            max_tokens=800,
        )

        print("OpenAI Response: ", response)

        content = response.choices[0].message.content.strip()
        if not content:
            raise HTTPException(status_code=500, detail="OpenAI returned empty response.")
        
        try:
            return json.loads(content)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"OpenAI returned invalid JSON: {str(e)}\nContent was: {content}")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OpenAI call failed: {str(e)}")



async def call_openai_summary(summary_prompt: str) -> str:
    openai_key = get_openai_key()
    if not openai_key:
        raise HTTPException(status_code=400, detail="OpenAI API key not configured")
    
    client = OpenAI(api_key=openai_key)

    system_instruction = (
        "You are a smart summarizer. Given a series of steps and responses, "
        "generate a friendly natural language summary for the user. "
        "Do NOT include JSON. Just explain the final result simply."
    )

    try:
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": system_instruction},
                {"role": "user", "content": summary_prompt}
            ],
            temperature=0,
            max_tokens=500,
        )
        content = response.choices[0].message.content.strip()
        if not content:
            raise HTTPException(status_code=500, detail="OpenAI summarization returned empty response.")
        return content
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"OpenAI summarization failed: {str(e)}")




async def call_mcp_server(mcp_info: Dict[str, Any], payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            resp = await client.post(f"{mcp_info['base_url']}/process", json=payload)
            resp.raise_for_status()
            return resp.json()
    except Exception as e:
        return {"error": f"Failed to call MCP server {mcp_info['name']}: {str(e)}"}

# --- API Endpoints ---

@app.get("/health")
def health_check():
    return {"status": "Backend is healthy ✅"}

@app.post("/config/openai")
def set_openai_key_api(api_key: str):
    set_openai_key(api_key)
    return {"message": "OpenAI API key configured successfully"}

@app.post("/config/mcp_server")
async def add_mcp_server(config: MCPServerConfig):
    manifest = await fetch_manifest(config.base_url)
    mcp_id = add_mcp_server_db(config.name, config.base_url, manifest)
    return {"message": "MCP server added", "mcp_id": mcp_id}

@app.get("/config/mcp_servers")
def list_mcp_servers():
    servers = list_mcp_servers_db()
    return [{"mcp_id": server["mcp_id"], "name": server["name"], "base_url": server["base_url"]} for server in servers]

@app.delete("/config/mcp_server/{mcp_id}")
def delete_mcp_server(mcp_id: str):
    delete_mcp_server_db(mcp_id)
    return {"message": "MCP server deleted successfully"}

@app.get("/chat_sessions")
def get_chat_sessions():
    conn = get_db_connection()
    rows = conn.execute(
        "SELECT DISTINCT session_id, COALESCE(NULLIF(session_title, ''), '(Untitled Session)') AS session_title FROM chat_history ORDER BY created_at DESC"
    ).fetchall()
    conn.close()

    return [
        {"session_id": row["session_id"], "session_title": row["session_title"]}
        for row in rows
    ]

@app.get("/chat_history/{session_id}")
def get_chat_history(session_id: str):
    return load_chat_history(session_id)

@app.post("/process_prompt")
async def process_prompt(request: UserPromptRequest):
    openai_key = get_openai_key()
    if not openai_key:
        raise HTTPException(status_code=400, detail="OpenAI API key missing")

    async def event_generator():
        try:
            servers = list_mcp_servers_db()
            available_servers = []
            for server in servers:
                manifest = json.loads(server.get("manifest", "{}"))
                available_servers.append({
                    "name": server["name"],
                    "base_url": server["base_url"],
                    "actions": manifest.get("actions", [])
                })

            yield f"event:status\ndata:Refining your prompt with OpenAI...\n\n"
            refined_response = await call_openai(request.prompt, available_servers)

            sequence = refined_response
            results = []

            for step in sequence:
                server_name = step["server_name"]
                payload = {k: v for k, v in step.get("payload", {}).items() if v is not None}
                matching = [s for s in servers if s["name"] == server_name]
                if not matching:
                    yield f"event:error\ndata:Server {server_name} not found\n\n"
                    continue

                server_info = matching[0]
                yield f"event:status\ndata:Calling MCP Server: {server_name}...\n\n"
                response = await call_mcp_server({
                    "name": server_info["name"],
                    "base_url": server_info["base_url"]
                }, payload)

                results.append({
                    "server_name": server_name,
                    "request": payload,
                    "response": response
                })

            yield f"event:status\ndata:Summarizing final answer with OpenAI...\n\n"
            final_summary_prompt = (
                f"Given the following steps:\n{json.dumps(results, indent=2)}\n"
                f"Summarize the final result nicely for the user."
            )
            final_response = await call_openai_summary(final_summary_prompt)

            # Send back response FIRST
            final_payload = {
                "session_id": request.session_id,
                "steps": results,
                "final_answer": final_response
            }
            yield f"event:result\ndata:{json.dumps(final_payload)}\n\n"

            # --- After sending result, now safe to update DB ---
            conn = get_db_connection()
            row = conn.execute(
                "SELECT session_title FROM chat_history WHERE session_id = ? LIMIT 1",
                (request.session_id,)
            ).fetchone()
            conn.close()

            if row and row["session_title"]:
                short_title = row["session_title"]
            else:
                short_title = (await call_openai_summary(f"Give a short 3 to 5 words session title for following prompt:\n{request.prompt}")).strip().strip('"')

            save_chat_history(
                session_id=request.session_id,
                session_title=short_title,
                user_prompt=request.prompt,
                steps=results,
                final_answer=final_response
            )

        except Exception as e:
            yield f"event:error\ndata:{str(e)}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")



# calculate the area of box 4cm and 5cm in size