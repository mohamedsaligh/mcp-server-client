# file: pages/config.py

import streamlit as st
import requests

# --- Helper to handle rerun-success messages ---
def rerun_with_success(flag_name: str, message: str):
    if st.session_state.get(flag_name):
        st.success(message)
        del st.session_state[flag_name]

def set_success_and_rerun(flag_name: str):
    st.session_state[flag_name] = True
    st.rerun()

# --- Streamlit Page Config ---
st.set_page_config(page_title="🛠️ MCP Configurations", layout="wide")

# --- Backend Base URL ---
BACKEND_URL = "http://localhost:8000"

# --- Sidebar Menu ---
with st.sidebar:
    st.title("📋 Menu")
    st.page_link("frontend.py", label="💬 ChatBot")
    st.page_link("pages/config.py", label="🛠️ Manage Configurations")
    st.divider()

# --- Main Title ---
st.title("🛠️ Configuration Management")

# --- Show success messages after rerun if needed ---
rerun_with_success("server_added_success", "✅ MCP server added successfully!")
rerun_with_success("server_deleted_success", "✅ MCP server deleted successfully!")
rerun_with_success("openai_key_saved", "✅ OpenAI API key saved successfully!")

# --- Section: OpenAI Key Setup ---
st.subheader("🔑 OpenAI API Key Setup")

# 1. Fetch Existing OpenAI Key
existing_openai_key = ""
try:
    response = requests.get(f"{BACKEND_URL}/config/openai")
    if response.status_code == 200:
        existing_openai_key = response.json().get("api_key", "")
except Exception as e:
    st.error(f"Failed to fetch existing OpenAI Key: {str(e)}")

# 2. Textbox pre-filled with existing key
openai_api_key = st.text_input(
    "Enter OpenAI API Key",
    type="password",
    value=existing_openai_key,
    placeholder="sk-..."
)

# 3. Save Button
if st.button("Save OpenAI API Key"):
    if openai_api_key:
        res = requests.post(f"{BACKEND_URL}/config/openai", params={"api_key": openai_api_key})
        if res.status_code == 200:
            set_success_and_rerun("openai_key_saved")
        else:
            st.error("Failed to set OpenAI key.")

st.divider()

# --- Section: MCP Server Management ---
st.subheader("🖥️ MCP Server Management")

st.markdown("### ➕ Add MCP Server")

with st.form("add_mcp_server_form"):
    mcp_name = st.text_input("Server Name", placeholder="Example: Area Calculator")
    mcp_url = st.text_input("Server URL", placeholder="Example: http://localhost:8001")
    submitted = st.form_submit_button("Add MCP Server")

    if submitted and mcp_name and mcp_url:
        res = requests.post(
            f"{BACKEND_URL}/config/mcp_server",
            json={"name": mcp_name, "base_url": mcp_url}
        )
        if res.status_code == 200:
            set_success_and_rerun("server_added_success")
        else:
            st.error("Failed to add MCP server.")

st.divider()

st.subheader("🗑️ Existing MCP Servers")

try:
    mcp_servers = requests.get(f"{BACKEND_URL}/config/mcp_servers").json()

    if not mcp_servers:
        st.info("No MCP servers configured yet.")
    else:
        for server in mcp_servers:
            with st.container(border=True):
                col1, col2 = st.columns([24, 1])

                with col1:
                    st.markdown(f"**{server['name']}**  \n`{server['base_url']}`")

                with col2:
                    if st.button("❌", key=f"delete_{server['mcp_id']}"):
                        res = requests.delete(f"{BACKEND_URL}/config/mcp_server/{server['mcp_id']}")
                        if res.status_code == 200:
                            set_success_and_rerun("server_deleted_success")
                        else:
                            st.error(f"Failed to delete {server['name']}")
except Exception as e:
    st.error(f"Failed to fetch servers: {str(e)}")
