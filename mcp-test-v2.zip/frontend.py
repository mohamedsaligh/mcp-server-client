import streamlit as st
st.switch_page("pages/chatbot.py")
